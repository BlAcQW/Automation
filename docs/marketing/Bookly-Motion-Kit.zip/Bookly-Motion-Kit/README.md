# Bookly motion kit

Assets for Bookly's 30-second launch film (1920 × 1080, 60 fps, 1800 frames). The storyboards in `00-reference` say what happens in every scene and when; this kit has the pieces to build it.

Start with `00-reference/Bookly-Launch-Video-Storyboards.pdf`. Pick one of the five storylines; each has its own folder here (`03` to `07`).

## Folders

| Folder | What's in it |
|---|---|
| `00-reference` | The storyboard PDF: hero frame, motion beats by frame, copy and type specs, camera, sound and voice-over for every scene. |
| `01-brand` | Wordmark (vector, one path per letter), awning stripe (vector, one circle per scallop), tick, phone frame, clock face and hands, generic channel tiles, badge, cursor, colour palette (`.ase` for Adobe apps and `.json`). |
| `02-ui-shared` | Pieces used in several storylines: Mobile Money sheet, typing indicators, status pills, the "Start free" button, URL and tagline, and a flat end card. |
| `03-sb1-the-9pm-message` | Storyboard 1. |
| `04-sb2-three-inboxes-one-diary` | Storyboard 2 (includes `channel-streams.svg` for trim-path animation). |
| `05-sb3-the-empty-set` | Storyboard 3. |
| `06-sb4-hands-full` | Storyboard 4. |
| `07-sb5-by-tonight` | Storyboard 5 (includes `progress-bar.svg` and the dusk background). |
| `08-style-frames` | The hero frame of all 25 scenes at 1920 × 1080, for matching layout and look. |
| `09-photos` | Full-resolution photos and background plates (JPG). Files starting `plate-` are made for a specific scene, e.g. `plate-sb3-s1-empty-studio.jpg`. |

Files in each storyline folder start with the scene number (`s1-` … `s5-`). Chat pieces are numbered in the order they appear (`s3-wa-01-…`, `s3-wa-02-…`).

## Sizes and scale

- **UI pieces are PNGs at 2×.** They were laid out on a 1920 × 1080 frame, so place them at **50% scale** in a 1080p comp (or 100% in a 4K comp). That leaves room for the 125–130% push-ins in the storyboards without going soft.
- **Phone screens** are 412 × 872 at 1080p (824 × 1744 px in the files). They sit in `phone-frame-440x900.svg` at x 14, y 14, corner radius 52. Chat bubbles were sized for that screen width.
- **Style frames and the end card** are 1920 × 1080 at 1×.
- **Transparency:** every UI piece has a transparent background. The lock-screen notifications are semi-transparent white made for the dark lock screen, so they look faint on a light background.
- **No shadows are baked in**, so you can light each layer yourself. For a match with the storyboards: cards `0 40 px 80 px -30 px` at 30–35% black; the phone `0 40 px 80 px -30 px` at 55%.

## Vectors (SVG)

- `bookly-wordmark-*.svg`: the wordmark as outlines in four colours. Each letter is its own path (`letter-1-B` … `letter-6-y`) for the letter-by-letter build on the end card.
- `awning-stripe-1920x46.svg`: each scallop is a separate circle (`scallop-01` …) for the left-to-right drop; the band is `band`.
- `tick.svg`: `tick-circle` plus `tick-check` (a stroke, so you can trim-path draw it before the spring).
- `clock-face-*.svg` plus the separate hands: every hand points at 12 in a 600 × 600 box. Put the anchor point at **300, 300** and rotate.
- `channel-streams.svg` (storyboard 2) and `progress-bar.svg` (storyboard 5) are made for trim paths and scale animation.

**In After Effects:** open an SVG in Illustrator, save it as `.ai`, import it as a composition with layer sizes kept, then use *Create Shapes from Vector Layer*. The layer names carry over.

## Fonts

The fonts aren't included (Clash Display's licence doesn't allow passing the files around). Both are free:

- **Clash Display** (headlines and wordmark only): https://www.fontshare.com/fonts/clash-display. Use weight 600, tracking −2% (−3% for the wordmark).
- **Bricolage Grotesque** (everything else): https://fonts.google.com/specimen/Bricolage+Grotesque. Use 400–700. It includes the cedi sign ₵.

Type sizes for every line of copy are in the PDF, per scene.

## Colours

`01-brand/bookly-palette.ase` loads straight into the Swatches panel. The main ones:

| Name | Hex | Use |
|---|---|---|
| Cream | `#FAF6EE` | Background, about 60% of a frame |
| Green | `#0F6B4F` | Headlines, buttons, ticks |
| Gold | `#E8A317` | One highlight per frame; the awning. Never body text on cream |
| Charcoal | `#1F2328` | Text; dark scenes |
| Coral | `#E8735F` | Problem accents on dark backgrounds |

## Motion, in short

Entrances take 12–18 frames, ease-out `cubic-bezier(0.22, 1, 0.36, 1)`, and rise 8–16 px from 15–40% opacity. Lists stagger 4–5 frames. Kinetic type is 6 frames per word. A press is 97% for 6 frames. The tick pop is an 18-frame stroke draw, then a 100 → 115 → 100% spring over 12 frames. The PDF has the full rules and the frame-by-frame beats.

## Please keep in mind

- **Logo:** logo work is on hold. Use the plain wordmark only: no monogram, no logo reveal.
- **CTA:** **booklygh.com**.
- **Channel icons are generic tiles, not the official logos.** If you want the real WhatsApp, Instagram or Messenger logos, take them from Meta's brand resources and follow their rules. Don't use real app notification sounds.
- **Mobile Money is shown generically.** Don't add a network's logo.
- **Example content only:** businesses, people, prices and numbers are made up. The photos and plates were generated with AI (Higgsfield); no real customers appear.
- **Contrast and flashes:** keep text readable (at least 4.5:1, or 3:1 for big headlines) and never more than one flash per second.
